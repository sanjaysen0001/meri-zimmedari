import Routerfile from './Routers/Routerfile'
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';


function App() {
  return (
  <>
  <Routerfile/>
  
  </>
  );
}

export default App;
