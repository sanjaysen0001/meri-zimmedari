import { useState } from "react";
import Mynavbar from "./Mynavbar";


const Help = () => {
    const [name, setName] = useState('');
    const [email, setEmail] = useState('');
    const [message, setMessage] = useState('');
  
    const handleSubmit = (e) => {
      e.preventDefault();
      // Here you can implement the logic to handle the form submission
      console.log('Name:', name);
      console.log('Email:', email);
      console.log('Message:', message);
      // Reset form fields
      setName('');
      setEmail('');
      setMessage('');
    };
  return (
    <>
    <Mynavbar/>
    <div className='container'>
    <p style={{fontSize:'24px',color:'rgb(43, 77, 129)' ,fontWeight:'500'}}>
    <span>Help </span>
    <span>
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="currentColor" class="bi bi-arrow-right" viewBox="0 0 16 16">
    <path fill-rule="evenodd" d="M1 8a.5.5 0 0 1 .5-.5h11.793l-3.147-3.146a.5.5 0 0 1 .708-.708l4 4a.5.5 0 0 1 0 .708l-4 4a.5.5 0 0 1-.708-.708L13.293 8.5H1.5A.5.5 0 0 1 1 8"/>
  </svg>
    </span>
        
        
        </p>
    <h2 style={{textAlign:'center'}}>Enquiry Form</h2>
    <form onSubmit={handleSubmit}>
    <div className="mb-3">
      <label htmlFor="name" className="form-label">Name</label>
      <input type="text" className="form-control" id="name" value={name} onChange={(e) => setName(e.target.value)} />
    </div>
    <div className="mb-3">
      <label htmlFor="email" className="form-label">Email</label>
      <input type="email" className="form-control" id="email" value={email} onChange={(e) => setEmail(e.target.value)} />
    </div>
    <div className="mb-3">
      <label htmlFor="message" className="form-label">Message</label>
      <textarea className="form-control" id="message" rows="3" value={message} onChange={(e) => setMessage(e.target.value)}></textarea>
    </div>
    <button type="submit" className="btn btn-primary">Submit</button>
  </form>
    </div>
    </>
  )
}

export default Help