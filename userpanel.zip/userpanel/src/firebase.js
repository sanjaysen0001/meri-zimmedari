// // Import the functions you need from the SDKs you need
// import firebase from "firebase";
// // import 'firebase/auth'
// // import { initializeApp } from "firebase/app";
// // TODO: Add SDKs for Firebase products that you want to use
// // https://firebase.google.com/docs/web/setup#available-libraries

// // Your web app's Firebase configuration
// const firebaseConfig = {
//   apiKey: "AIzaSyAAQIjwDT7_v9ZPqSzhY2RNZMt86yYwkFI",
//   authDomain: "smsotpsend.firebaseapp.com",
//   projectId: "smsotpsend",
//   storageBucket: "smsotpsend.appspot.com",
//   messagingSenderId: "945986785166",
//   appId: "1:945986785166:web:bc8d899a13f9ec1da2dedf",
// };

// // Initialize Firebase
// firebase.initializeApp(firebaseConfig);
// // const app = initializeApp(firebaseConfig);
// export default firebase;

// import firebase from "firebase/app";

// hello firebase
// import * as firebase from "firebase";
// import "firebase/auth";

// var firebaseConfig = {
//   apiKey: "AIzaSyAAQIjwDT7_v9ZPqSzhY2RNZMt86yYwkFI",
//   authDomain: "smsotpsend.firebaseapp.com",
//   projectId: "smsotpsend",
//   storageBucket: "smsotpsend.appspot.com",
//   messagingSenderId: "945986785166",
//   appId: "1:945986785166:web:bc8d899a13f9ec1da2dedf",
// };
// // Initialize Firebase
// firebase.initializeApp(firebaseConfig);

// export default firebase;
