import React from 'react'

const Splashscreen = () => {
  return (
    <div className='flex'>
         <div className='text-center font-bold text-slate-950 text-2xl  w-full h-full justify-center items-center '>Welcome</div>
    </div>
  )
}

export default Splashscreen
